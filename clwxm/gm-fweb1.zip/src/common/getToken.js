const getToken = {
    function (Vue, options) {
       
    }
}



export default getToken;